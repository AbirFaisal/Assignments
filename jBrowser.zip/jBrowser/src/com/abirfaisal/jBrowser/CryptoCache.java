package com.abirfaisal.jBrowser;

/**
 * Proposed feature
 * Encrypted Cache
 *
 * Holds:
 * Settings
 * History
 * WebEngineCache
 * Tab Cache
 * Tab Objects
 *
 *
 *
 *
 */
public class CryptoCache {
}
