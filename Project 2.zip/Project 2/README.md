# COP2800GroupWork

This is a group project repository for our COP2800 class Exam 2


###Assignment can be found in Assignment.pdf
